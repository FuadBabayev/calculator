  function num0(){
    document.getElementById("display").innerHTML = "0";
  }
    function num1(){
        document.getElementById("display").innerHTML = "1";
      }

      function num2(){
        document.getElementById("display").innerHTML = "2";
      }
      function num3(){
        document.getElementById("display").innerHTML = "3";
      }
      function num4(){
        document.getElementById("display").innerHTML = "4";
      }
      function num5(){
        document.getElementById("display").innerHTML = "5";
      }
      function num6(){
        document.getElementById("display").innerHTML = "6";
      }
      function num7(){
        document.getElementById("display").innerHTML = "7";
      }
      function num8(){
        document.getElementById("display").innerHTML = "8";
      }
      function num9(){
        document.getElementById("display").innerHTML = "9";
      }
            function hesab(){
          let x = document.getElementById("reqem2").innerHTML;
              y = document.getElementById("reqem3").innerHTML;
              z = document.getElementById("multiple").value;
              document.getElementById("display").innerHTML = eval(x + z + y);
      }

     
